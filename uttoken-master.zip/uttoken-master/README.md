# uttoken
UTT smart contract
